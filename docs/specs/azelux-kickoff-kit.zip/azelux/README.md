# Azelux

Compare two lunar landing plans (site + date) and see how much sunlight and direct Earth contact
each one gets, computed against the real terrain skyline from NASA LOLA data and NASA/JPL SPICE
ephemerides. Built for the NASA Space Apps Challenge 2026.

> Planning and education aid only: not a landing-safety certification, power forecast or radio-link guarantee.

## Quick start
```bash
git clone <repo-url> && cd azelux
make hooks            # installs the commit-msg guard (required before your first commit)
cp .env.example .env
make dev              # backend http://localhost:8000, frontend http://localhost:5173
```

## Data
Run `scripts/download_kernels.py` and `scripts/download_dems.py` (written in S0) to fetch NASA data into `data/` (git-ignored).

## Team
<names and roles, filled at kickoff>
