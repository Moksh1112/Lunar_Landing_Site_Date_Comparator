# Azelux — PROJECT.md            (updated <time IST> by P1)

## Brief
User: lunar mission planners, educators, public.  Pain: comparing landing sites/dates for Sun
(power) and Earth (direct comms) visibility means juggling Quickmap, Moon Trek and Horizons.
Value: compare two landing plans in one view and see exactly what changes, with real terrain.
Primary journey: 1. pick Scenario A and B (site + date + mission length) -> 2. Compare ->
3. read verdicts, deltas, horizon panorama and timeline; try a shifted date or best-date finder.
Wow moment: change B's date and watch Earth contact disappear behind a ridge in the panorama.
Event: NASA Space Apps 2026, online judging. Deadline: Sun 15 Nov 2026 23:59 IST (submit by 23:00).

## Team board
| Slot | Name | Role | Folders | Branch prefix |
| --- | --- | --- | --- | --- |
| P1 | <name> | Integration lead, DevOps, QA, submission; shell, API client, 2D map | root, .github, scripts, fixtures, frontend/src/api, app, features/map | feat/p1-* |
| P2 | <name> | Backend lead, contract owner; ephemeris, metrics, sweep, API | backend/app/api, ephemeris, metrics, sites (code) | feat/p2-* |
| P3 | <name> | Terrain: DEMs, skyline, coverage, tiles; south-pole site data | backend/app/terrain, scripts/prepare_dems.py, precompute_skylines.py, sites.json (pole) | feat/p3-* |
| P4 | <name> | Frontend lead, Coordinator owner; Compare page | frontend/src/features/compare, theme, store.ts | feat/p4-* |
| P5 | <name> (Sun) | 3D view, time scrubber, best-date page | frontend/src/features/view3d, bestdate, scrubber | feat/p5-* |
| P6 | <name> (Sun) | Validation V1-V6, methods page, report, exports; non-polar site data | validation/, docs/METHODS.md, features/methods, report, sites.json (non-polar) | feat/p6-* |

## Timeline (IST)
| Stage | Window | Sync |
| --- | --- | --- |
| S0 Setup + contract | Sat 13:00-15:00 | Sync 0 15:00 |
| S1 Walking skeleton | Sat 15:00-20:00 | Sync 1 20:00 |
| S2 First real slice | Sat 20:00-Sun 02:00 | Sync 2 02:00 |
| Rest | Sun 02:00-08:00 | - |
| S3 Complete MVP | Sun 08:00-13:00 | Sync 3 13:00 |
| S4 Harden + MVP gate | Sun 13:00-15:00 | MVP gate 15:00 |
| Iteration 1 | Sun 15:00-19:00 | It.1 exit 19:00 |
| Iteration 2 | Sun 19:00-21:00 | FEATURE FREEZE 21:00 (rc-1) |
| S5 Video + submit | Sun 21:00-23:00 | Final 23:00 |

## Status          (P1 updates at every sync)
main: <tag/commit>        Last sync passed: <n>
Works for real: <...>
Still mocked: <...>
Known bugs/limits: <...>
Next per person: <...>

## Decisions and assumptions
D1-D9: see TRD section 11.  A1: verdict thresholds 50/50/48/72 until the team changes them.

## Cut order (only at checkpoints, by team decision)
1. 3D animation  2. 3D view  3. PDF report (keep CSV/JSON)  4. sweep refinement  5. Iteration 2  6. Iteration 1 features
Never cut: A vs B comparison, real data, terrain, panorama, timeline, source labels.
